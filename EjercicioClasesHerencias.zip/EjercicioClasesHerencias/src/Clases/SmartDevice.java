package Clases;

public class SmartDevice {

    public String nombre;
    int RAM;
    public double price;
    public int year;

    public SmartDevice(){};

    public SmartDevice(String nombre, double price, int year){
        this.nombre = nombre;
        this.price = price;
        this.year = year;
    };


}
