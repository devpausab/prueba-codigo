package Clases.Hijos;

import Clases.SmartDevice;

public class SmartPhone extends SmartDevice{
    public int RAM;
    public String sistemaOperativo;

    public SmartPhone (){}

    public SmartPhone(String nombre, double price, int year, int RAM, String sistemaOperativo) {
        super(nombre, price, year);
        this.RAM = RAM;
        this.sistemaOperativo = sistemaOperativo;
    }
}
