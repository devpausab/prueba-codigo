package Clases.Hijos;

import Clases.SmartDevice;

public class SmartWatch extends SmartDevice{
    public String pantalla;
    public String materialCorrea;

    public SmartWatch (){}

    public SmartWatch(String nombre, double price, int year, String pantalla, String materialCorrea) {
        super(nombre, price, year);
        this.pantalla = pantalla;
        this.materialCorrea = materialCorrea;
    }
}
