package Main;
import Clases.Hijos.SmartPhone;
import Clases.Hijos.SmartWatch;
import Clases.SmartDevice;

import java.sql.SQLOutput;


public class Main {
    public static void main(String[] args) {
        SmartDevice Lavadora = new SmartDevice("Lavatodo300", 399.99, 2016);
        System.out.println("Los atributos del Smartdevice son:");
        System.out.println(Lavadora.nombre);
        System.out.println(Lavadora.price);
        System.out.println(Lavadora.year);

        SmartWatch Watch = new SmartWatch("Casio 320", 249.99, 2017, "53x53", "Goma");
        System.out.println("Los atributos del Smartwatch son:");
        System.out.println(Watch.nombre);
        System.out.println(Watch.price);
        System.out.println(Watch.year);
        System.out.println(Watch.pantalla);
        System.out.println(Watch.materialCorrea);

        SmartPhone Phone = new SmartPhone("Huawei 77", 349.99, 2020, 8, "Android");
        System.out.println("Los atributos del Smartphone son:");
        System.out.println(Phone.nombre);
        System.out.println(Phone.price);
        System.out.println(Phone.year);
        System.out.println(Phone.RAM);
        System.out.println(Phone.sistemaOperativo);

    }
}
